//
//  CustomCell.swift
//  RxSwiftStuff
//
//  Created by Volodymyr Shlikhta on 1/25/18.
//  Copyright © 2018 Volodymyr Shlikhta. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var valueLabel: UILabel!
    @IBOutlet weak var currencyLabel: UILabel!
}
