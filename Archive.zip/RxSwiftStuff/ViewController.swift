//
//  ViewController.swift
//  RxSwiftStuff
//
//  Created by Volodymyr Shlikhta on 1/25/18.
//  Copyright © 2018 Volodymyr Shlikhta. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift
import Foundation

fileprivate let cellIdentifier = "CustomCell"

class DisplayItem {
    var symbol: String
    var isFavorite: Bool = false
    private let price = Variable<Double>(0)
    var priceObservable: Observable<Double> {
        return price.asObservable()
    }
    
    init(symbol: String, favorite: Bool) {
        self.symbol = symbol
        self.isFavorite = favorite
    }
    
    func update(_ price: Double) {
        self.price.value = price
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var customTableView: UITableView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var showFavoriteSwitch: UISwitch!
    
    
    fileprivate var bag = DisposeBag()
    var allItems = Variable<[DisplayItem]>([])
    var testSymbols = ["USD", "EUR", "UAH"]
    var items = Variable<[DisplayItem]>([])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customTableView.delegate = self
        customTableView.dataSource = self
        allItems.value = testSymbols.enumerated().map({ DisplayItem(symbol: $1, favorite: $0 % 2 == 0)
        })
        items.value = allItems.value
    }
    
    func bindUI() {
        Observable.combineLatest (
            allItems.asObservable(),
            showFavoriteSwitch.rx.isOn,
            searchTextField.rx.text,
            resultSelector: { (currentPrices, onlyFavorites, search) in
                return currentPrices.filter { price -> Bool in
                    return self.shouldDisplayPrice(forItem: price,
                                              search: search,
                                              onlyFavorites: onlyFavorites)
                }
                
        })
        .bind(to: items)
        .disposed(by: bag)
    }
    
    fileprivate func shouldDisplayPrice(forItem item: DisplayItem, search: String?, onlyFavorites: Bool) -> Bool {
        if onlyFavorites && !item.isFavorite {
            return false
        }
        guard let search = search else {
            return false
        }
        if search.isEmpty && item.symbol.contains(search) {
            return false
        }
        return true
    }
    
    fileprivate func update(items: [DisplayItem], with newItems: [String: Double]) -> [DisplayItem] {
        for (key, newItem) in newItems {
            if let item = items.filter({ $0.symbol == key }).first {
                item.update(newItem)
            }
        }
        return items
    }
    
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    
    
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
